document.addEventListener('DOMContentLoaded', function () {
    const btnMasuk = document.getElementById('btn-masuk');
    const btnDaftar = document.getElementById('btn-daftar');
    const btnGoogle = document.getElementById('btn-google');

    if (btnMasuk) {
        btnMasuk.addEventListener('click', function () {
            btnMasuk.classList.add('active');
            btnDaftar.classList.remove('active');
        });
    }

    if (btnDaftar) {
        btnDaftar.addEventListener('click', function () {
            btnDaftar.classList.add('active');
            btnMasuk.classList.remove('active');
            alert('Navigasi ke halaman pendaftaran');
        });
    }

    if (btnGoogle) {
        btnGoogle.addEventListener('click', function () {
            alert('Fitur login dengan Google belum dihubungkan ke API.');
        });
    }

    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.reset();
    }

    const passwordInput = document.getElementById('password');
    const togglePasswordBtn = document.getElementById('toggle-password');

    const eyeOpenSVG = `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
            <circle cx="12" cy="12" r="3"></circle>
        </svg>
    `;

    const eyeClosedSVG = `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
            <line x1="1" y1="1" x2="23" y2="23"></line>
        </svg>
    `;

    if (togglePasswordBtn && passwordInput) {
        togglePasswordBtn.innerHTML = eyeOpenSVG;

        togglePasswordBtn.addEventListener('click', function () {
            const isPassword = passwordInput.getAttribute('type') === 'password';

            passwordInput.setAttribute('type', isPassword ? 'text' : 'password');

            togglePasswordBtn.innerHTML = isPassword ? eyeClosedSVG : eyeOpenSVG;
        });
    }
});